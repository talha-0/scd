package interfaces;

public interface Configuration {
    void displayInfo();
    double calculateCost();
}